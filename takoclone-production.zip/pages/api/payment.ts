import { snap } from "@/lib/midtrans";
export default async function handler(req, res) {
  const parameter = {
    transaction_details: {
      order_id: "DON-" + Date.now(),
      gross_amount: req.body.amount,
    },
    callbacks: {
      finish: `${process.env.NEXT_PUBLIC_BASE_URL}/thank-you`,
    },
  };
  const transaction = await snap.createTransaction(parameter);
  res.json({ token: transaction.token });
}