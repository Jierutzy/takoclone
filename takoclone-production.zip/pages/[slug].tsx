import { GetServerSideProps } from "next";
export default function PublicProfile({ profile, donations }) {
  return (
    <div className="max-w-xl mx-auto p-4">
      <h1 className="text-2xl font-bold mb-2">{profile.displayName}</h1>
      <p>{profile.bio}</p>
      <h2 className="mt-6 font-semibold">💖 Dukungan Terbaru</h2>
      <ul>
        {donations.map(d => (
          <li key={d.id}>{d.amount} - {d.message}</li>
        ))}
      </ul>
    </div>
  );
}